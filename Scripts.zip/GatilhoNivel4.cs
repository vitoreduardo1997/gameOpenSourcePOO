﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class GatilhoNivel4 : MonoBehaviour
{
	private GameObject portaEsquerda;
	private GameObject portaDireita;
	public GameObject objColisao;
	public GameObject chaoLava;
	public GameObject cuboAzul;
	public TextMeshProUGUI txtFail;
	public AudioSource somAcerto;
	public AudioSource somErro;
	public Canvas questao;

	void Start()
    {
		questao.enabled = false;
    }

	public void OnTriggerEnter(Collider colisao)
	{
		portaEsquerda = GameObject.Find("portaEsquerda");
		portaDireita = GameObject.Find("portaDireita");

		if (colisao.tag == "Player")
		{
			if(objColisao.tag == "cuboGatilhoQuestao")
            {
				questao.enabled = true;
            }
			else if (objColisao.tag == "terrainLava")
			{
				somErro.Play();
				txtFail.text = "Você caiu na lava! Tente novamente.";
				Invoke("carregarExplicacao", 3);
			}
			else if (objColisao.tag == "cuboAzul")
			{
				somAcerto.Play();
				txtFail.text = "A porta foi aberta.";
				Invoke("apagarTexto", 2);
				cuboAzul.transform.position = new Vector3(59.32F, 7.750005F, 1.19F);
				abrirPortas();
			}
			else if (objColisao.tag == "ColisorAgradecimentos" && portaEsquerda.transform.position.x < 5.97F)
			{
				SceneManager.LoadScene("agradecimentos");
			}
		}
	}

	public void carregarExplicacao()
	{
		SceneManager.LoadScene("explicacaoNivel4");
	}

	public void abrirPortas()
	{
		portaEsquerda = GameObject.Find("portaEsquerda");
		portaDireita = GameObject.Find("portaDireita");
		portaEsquerda.transform.position = new Vector3(0.3F, 0F, 0F);
		portaDireita.transform.position = new Vector3(0.3F, -0.1499473F, -1.43F);
	}

	public void apagarTexto()
	{
		txtFail.text = string.Empty;
	}
}
