﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// CLASSE ADICIONADA POR VITOR EDUARDO E LEONEL RIOS
public class GatilhoNivel1 : MonoBehaviour
{
	public GameObject portaEsquerdaNivel2;

	public void OnTriggerEnter(Collider colisao)
    {
		portaEsquerdaNivel2 = GameObject.Find("portaEsquerdaNivel2");

		if (colisao.tag == "Player" && portaEsquerdaNivel2.transform.position.x < 5.97F)
		{
			SceneManager.LoadScene("explicacaoNivel2");
		}
	}
}
