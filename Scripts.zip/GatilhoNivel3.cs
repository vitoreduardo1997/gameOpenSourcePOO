﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// CLASSE ADICIONADA POR VITOR EDUARDO E LEONEL RIOS
public class GatilhoNivel3 : MonoBehaviour
{
	private GameObject portaEsquerdaNivel3;
	private GameObject portaDireitaNivel3;
	public GameObject objColisao;
	public GameObject chaoLava;
	public GameObject cuboAmarelo;
	public GameObject cuboAzul;
	public TextMeshProUGUI txtFail;
	public AudioSource somAcerto;
	public AudioSource somErro;

	public void OnTriggerEnter(Collider colisao)
    {
		portaEsquerdaNivel3 = GameObject.Find("portaEsquerdaNivel3");
		portaDireitaNivel3 = GameObject.Find("portaDireitaNivel3");

		if (colisao.tag == "Player")
        {
			if(objColisao.tag == "terrainLava")
            {
				somErro.Play();
				txtFail.text = "Você caiu na lava! Tente novamente.";
				Invoke("carregarExplicacao", 3);
			}
			else if(objColisao.tag == "cuboAmarelo")
            {
				somAcerto.Play();
				txtFail.text = "A porta foi aberta.";
				Invoke("apagarTexto", 2);
				cuboAmarelo.transform.position = new Vector3(38.31F, 7.750005F, 1.1F);
				cuboAzul.transform.position = new Vector3(41.9F, 7.750005F, 0.2F);
				abrirPortasNivel3();
			}
			if (objColisao.tag == "cuboAzul")
			{
				somErro.Play();
				txtFail.text = "Botão errado! Tente novamente.";
				Invoke("carregarExplicacao", 3);
				cuboAzul.transform.position = new Vector3(41.9F, 7.750005F, 1.1F);
				cuboAmarelo.transform.position = new Vector3(38.31F, 7.750005F, 0.2F);
			}
			else if (objColisao.tag == "ColisorAgradecimentos" && portaEsquerdaNivel3.transform.position.x < 5.97F)
			{
				SceneManager.LoadScene("explicacaoNivel4");
			}
		}
	}

	public void carregarExplicacao()
    {
		SceneManager.LoadScene("explicacaoNivel3");
	}

	public void abrirPortasNivel3()
	{
		portaEsquerdaNivel3 = GameObject.Find("portaEsquerdaNivel3");
		portaDireitaNivel3 = GameObject.Find("portaDireitaNivel3");
		portaEsquerdaNivel3.transform.position = new Vector3(0.3F, 0F, 0F);
		portaDireitaNivel3.transform.position = new Vector3(0.3F, -0.1499473F, -1.43F);
	}

	public void apagarTexto()
    {
		txtFail.text = string.Empty;
	}
}
