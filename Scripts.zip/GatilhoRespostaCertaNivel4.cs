﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GatilhoRespostaCertaNivel4 : MonoBehaviour
{
	public TextMeshProUGUI txtResposta;
	public TextMeshProUGUI txtQuestao;
	public Button btnPublic;
	public Button btnPrivate;
	public Button btnProtected;
	public string resposta;
	public GameObject portaEsquerda;
	public GameObject portaDireita;
	public GameObject gradeMovel;
	public AudioSource somAcerto;
	public AudioSource somErro;

	public void responderQuestao()
	{
		portaEsquerda = GameObject.Find("portaEsquerda");
		portaDireita = GameObject.Find("portaDireita");

		if (resposta.Equals("private"))
		{
			somAcerto.Play();
			txtResposta.text = "Resposta certa! A grade foi aberta.";
			Invoke("apagarTexto", 2);
			abrirGrade();
		}
		else
		{
			somErro.Play();
			txtResposta.text = "Resposta errada! Tente novamente.";

			//invoca o método que carrega a explicação do nível após 2 segundos
			Invoke("carregarExplicacao", 2);
		}

		desativarBotoes();
		txtQuestao.gameObject.SetActive(false);
	}

	//desativa os botões para o jogador não clicar novamente após primeira tentativa
	private void desativarBotoes()
	{
		btnPublic.gameObject.SetActive(false);
		btnPrivate.gameObject.SetActive(false);
		btnProtected.gameObject.SetActive(false);
	}

	//volta à tela de explicação do nível
	private void carregarExplicacao()
	{
		SceneManager.LoadScene("explicacaoNivel4");
	}

	public void abrirPortas()
	{
		portaEsquerda.transform.position = new Vector3(0.45F, 0F, 0F);
		portaDireita.transform.position = new Vector3(0.45F, -0.1499473F, -1.43F);
	}

	public void abrirGrade()
    {
		gradeMovel.transform.position = new Vector3(53.34F, 9.2F, 6.32F);
    }

	private void apagarTexto()
    {
		txtResposta.text = string.Empty;
    }
}
