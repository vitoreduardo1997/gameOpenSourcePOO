﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// CLASSE ADICIONADA POR VITOR EDUARDO E LEONEL RIOS
public class GatilhoNivel2 : MonoBehaviour
{
	private GameObject portaEsquerdaNivel3;
	private GameObject portaDireitaNivel3;
	public GameObject cuboColisao;
	public GameObject cubeBotaoAzul;
	public GameObject cubeBotaoVermelho;
	public GameObject cubeBotaoAmarelo;
	public AudioSource somAcerto;
	public AudioSource somErro;

	public void OnTriggerEnter(Collider colisao)
	{
		portaEsquerdaNivel3 = GameObject.Find("portaEsquerdaNivel3");
		portaDireitaNivel3 = GameObject.Find("portaDireitaNivel3");

		if (colisao.tag == "Player")
		{
			if (cuboColisao.tag == "cuboAzul")
			{
				somAcerto.Play();
				cubeBotaoAzul.transform.position = new Vector3(53.7F, 6.590001F, 0.48F);
				cubeBotaoVermelho.transform.position = new Vector3(51.15F, 6.590001F, -0.04300034F);
				cubeBotaoAmarelo.transform.position = new Vector3(48.64F, 6.590001F, -0.04300034F);
				abrirPortasNivel3();
			}
			else if (cuboColisao.tag == "cuboVermelho")
			{
				somErro.Play();
				cubeBotaoAzul.transform.position = new Vector3(53.7F, 6.590001F, -0.04300034F);
				cubeBotaoVermelho.transform.position = new Vector3(51.15F, 6.590001F, 0.48F);
				cubeBotaoAmarelo.transform.position = new Vector3(48.64F, 6.590001F, -0.04300034F);
            }
			else if (cuboColisao.tag == "cuboAmarelo")
			{
				somErro.Play();
				cubeBotaoAzul.transform.position = new Vector3(53.7F, 6.590001F, -0.04300034F);
				cubeBotaoVermelho.transform.position = new Vector3(51.15F, 6.590001F, -0.04300034F);
				cubeBotaoAmarelo.transform.position = new Vector3(48.64F, 6.590001F, 0.48F);
            }
			else if(cuboColisao.tag == "ColisorNivel3" && portaEsquerdaNivel3.transform.position.x < 5.97F)
            {
				SceneManager.LoadScene("explicacaoNivel3");
			}
		}
    }

	public void abrirPortasNivel3()
	{
		portaEsquerdaNivel3 = GameObject.Find("portaEsquerdaNivel3");
		portaDireitaNivel3 = GameObject.Find("portaDireitaNivel3");
		portaEsquerdaNivel3.transform.position = new Vector3(0.45F, 0F, 0F);
		portaDireitaNivel3.transform.position = new Vector3(0.45F, -0.1499473F, -1.43F);
	}
}
