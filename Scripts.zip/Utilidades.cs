﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// CLASSE ADICIONADA POR VITOR EDUARDO E LEONEL RIOS
public class Utilidades : MonoBehaviour
{
	public string nomeCena;

	public void trocarCena()
    {
		SceneManager.LoadScene(nomeCena);
    }

	public void sairDoJogo()
    {
		Application.Quit();
    }
}
