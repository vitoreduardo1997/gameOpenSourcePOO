﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// CLASSE ADICIONADA POR VITOR EDUARDO E LEONEL RIOS
public class GatilhoRespostaCertaNivel1 : MonoBehaviour
{
	public TextMeshProUGUI txtResposta;
	public TextMeshProUGUI txtQuestao;
	public Button btnAviao;
	public Button btnVan;
	public Button btnCarro;
	public string resposta;
	public GameObject portaEsquerdaNivel2;
	public GameObject portaDireitaNivel2;
	public AudioSource somAcerto;
	public AudioSource somErro;

	public void responderQuestao()
    {
		portaEsquerdaNivel2 = GameObject.Find("portaEsquerdaNivel2");
		portaDireitaNivel2 = GameObject.Find("portaDireitaNivel2");

		if (resposta.Equals("AVIÃO"))
		{
			somAcerto.Play();
			txtResposta.text = "Resposta certa! Você desbloqueou o nível dois. Encontre uma saída.";
			abrirPortasNivel2();
		}
		else
		{
			somErro.Play();
			txtResposta.text = "Resposta errada! Tente novamente.";

			//invoca o método que carrega a explicação do nível após 2 segundos
			Invoke("carregarExplicacao", 2);
		}

		desativarBotoes();
		txtQuestao.gameObject.SetActive(false);
	}

	//desativa os botões para o jogador não clicar novamente após primeira tentativa
	private void desativarBotoes()
    {
		btnAviao.gameObject.SetActive(false);
		btnVan.gameObject.SetActive(false);
		btnCarro.gameObject.SetActive(false);
    }

	//volta à tela de explicação do nível
	private void carregarExplicacao()
    {
		SceneManager.LoadScene("explicacaoNivel1");
	}

	public void abrirPortasNivel2()
    {
		portaEsquerdaNivel2.transform.position = new Vector3(0.45F, 0F, 0F);
		portaDireitaNivel2.transform.position = new Vector3(0.45F, -0.1499473F, -1.43F);
    }
}
